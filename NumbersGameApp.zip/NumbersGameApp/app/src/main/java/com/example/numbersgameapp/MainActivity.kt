package com.example.numbersgameapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
var RNum= Random.nextInt(11)
    val userInput = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var mass1:String
        var mass2:String
        var GuessesNum=3
        val layout= this.findViewById<ConstraintLayout>(R.id.layout)
        val myRv =findViewById<RecyclerView>(R.id.rvMain)
        val button1=findViewById<Button>(R.id.button)
        val num = findViewById<EditText>(R.id.num).text


        myRv.layoutManager= LinearLayoutManager(this)


        button1.setOnClickListener{


          if(GuessesNum!=0){
               var number=num.toString()
               GuessesNum--
              myRv.adapter= recyclerView(this,userInput)
               if(number.toInt()!=RNum){

                 mass1="you guessed $num"
                 mass2="you have $GuessesNum left"
               userInput.add(mass1)
              userInput.add(mass2)
                   num.clear()
                   myRv.adapter?.notifyDataSetChanged()

              }
              else if(number.toInt()==RNum){
                   myRv.adapter= recyclerView(this,userInput)
                   userInput.add("you gat it!! it is $RNum")

                   button1.isEnabled = false
                   button1.isClickable = false
                   //guessField.isEnabled = false
                  // guessField.isClickable = false
              }

           }else if(num.isEmpty()){

           Toast.makeText(this,"enter a number pleas!!", Toast.LENGTH_SHORT).show()
           }else if(GuessesNum==0){
              myRv.adapter= recyclerView(this,userInput)

               userInput.add("game over")

           }




        }

        //myRv.adapter= recyclerView(userInput)

        //myRv.adapter?.notifyDataSetChanged()

    }
    }
